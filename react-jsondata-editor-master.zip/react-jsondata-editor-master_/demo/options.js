export default options = [
    {
        label: "Select From List",
        json: require("../JSONFiles/default.json"),
        value: []
    }
    , {
        label: 'FiberAvailability',
        json: require("../JSONFiles/FiberAvailability/connected.json"),
        value: [            //obj
            {
                label: 'Ausbaustand Glasfaser',
                array: [        //obj1
                    "connected", "ready", "prepared", "notplanned"
                ]
            },
            {
                label: 'Technologie',
                array: [
                    "FTTH", "FTTX"
                ]
            }
        ]
    },
    {
        label: 'QuickCheck',
        json: require("../JSONFiles/QuickCheck/quickcheck.json"),
        value: [
        ]
    }
]