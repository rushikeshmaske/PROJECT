import React, { useState, useCallback } from "react";
import { JsonEditor } from "../src/index";
import * as styles from './Index.module.css';
import options from './options'


/**
 *
 * Gets an input from a user and displays the input
 * Calls JsonParser to display a Json Object
 *
 * @returns {JSX.Element}
 *
 */
export default function Home() {

    const [result, setResult] = useState([]);
    const [input, setInput] = useState(require("../JSONFiles/default.json"))
    const [isId, setIsId] = useState(false);
    const [readonly, setReadonly] = useState(true)
    let currentEditObj = JSON.stringify(input, null, ' ')

    const [jsonInput, setJsonInput] = useState(currentEditObj)
    function changeJSONInput(data) {
        saveJsonString()
        currentEditObj = JSON.stringify(data, null, ' ')
        setJsonInput(currentEditObj)

    }

    function textSave(e) {
        setJsonInput(e.target.value)
    }

    function saveJsonString() {
        //console.log(options)
        if (currentEditObj === undefined) {
            setJsonInput('')
        } else {
            setJsonInput(currentEditObj)
        }
    }

    function ChangeService() {
        let res = this.menu.value;
        setIsId(false)
        setReadonly(false)
        options.map((obj) => {
            if (obj.label === res) {
                temp = obj.value
                setInput(obj.json)
                changeJSONInput(obj.json)
                setResult(obj.value);
                isIdFound(obj.json)
            }
        })
    }

    function changeEdit() {

        const response = confirm("You want to edit it?");

        setReadonly(!response);

    }

    function isIdFound(json) {
        let temp = flattenJSON(json)
        let searchId = Object.keys(temp).find(key => key === 'id')
        //console.log(searchId)
        if (searchId != null)
            setIsId(true)
    }
    function changeJson(e) {
        //console.log(typeof (e));
        let changeArray = e.split(",")
        //console.log(changeArray)
        changeValue(changeArray[1], changeArray[0])

    }
    function changeId() {
        let abc = input.id
        let demo = flattenJSON(input)
        let found = Object.keys(demo).filter(key => demo[key] === abc)
        found.forEach(element => {
            demo[element] = this.menu3.value
        });
        //for href
        if (Object.keys(demo).filter(key => key === "href")) {
            let temp = demo["href"]
            let changeArray = temp.split("/")
            changeArray[changeArray.length - 1] = this.menu3.value
            let text = changeArray.join('/')
            demo["href"] = text
        }
        setInput(unflatten(demo))
        changeJSONInput(unflatten(demo));
    }
    function changeValue(newValue, equalString) {
        {
            let demo = flattenJSON(input)
            let found = Object.keys(demo).find(key => demo[key] === equalString)
            console.log(found)
            let changeArray = found.split(".")
            changeArray[changeArray.length - 1] = "value"
            let text = changeArray.join('.')
            demo[text] = newValue
            setInput(unflatten(demo))
            changeJSONInput(unflatten(demo));

        }
    }
    var flattenJSON = function (data) {
        var result = {};
        function recurse(cur, prop) {
            if (Object(cur) !== cur) {
                result[prop] = cur;
            } else if (Array.isArray(cur)) {
                for (var i = 0, l = cur.length; i < l; i++)
                    recurse(cur[i], prop ? prop + "." + i : "" + i);
                if (l == 0)
                    result[prop] = [];
            } else {
                var isEmpty = true;
                for (var p in cur) {
                    isEmpty = false;
                    recurse(cur[p], prop ? prop + "." + p : p);
                }
                if (isEmpty)
                    result[prop] = {};
            }
        }
        recurse(data, "");
        return result;
    }

    let unflatten = function (data) {
        "use strict";
        if (Object(data) !== data || Array.isArray(data))
            return data;
        var result = {}, cur, prop, idx, last, temp;
        for (var p in data) {
            cur = result, prop = "", last = 0;
            do {
                idx = p.indexOf(".", last);
                temp = p.substring(last, idx !== -1 ? idx : undefined);
                cur = cur[prop] || (cur[prop] = (!isNaN(parseInt(temp)) ? [] : {}));
                prop = temp;
                last = idx + 1;
            } while (idx >= 0);
            cur[prop] = data[p];
        }
        return result[""];
    };

    function copyCodeToClipboard() {
        const el = this.textArea
        el.select()
        document.execCommand("copy")
        setCopied("Copied!!")
    }
    // function trial(e) {
    //     console.log(typeof (e));
    //     let changeArray = e.split(",")
    //     console.log(changeArray)

    // }
    return (
        <div className={styles.screenContainer}>
            <div className={styles.mainContainer}>
                <div className={styles.topContainer}>
                    <span>JSON EDITOR </span>
                </div>

                <div className={styles.selectContainer}>
                    <div className={styles.selectCompo}>
                        <label>Select Service:</label>
                        <select name="service" id="service" ref={(input) => this.menu = input} onChange={ChangeService}>{
                            options.map((obj) => {
                                return <option value={obj.label}>{obj.label}</option>
                            })
                        }</select></div>

                    {
                        result.map((obj) => {
                            return <div className={styles.selectCompo}>

                                <label>{obj.label}</label>
                                <select name="service2" id="service2" ref={(input) => this.menu2 = input} onChange={(e) => changeJson(e.target.value)} >{
                                    obj.array.map((obj1) => {
                                        return <option value={[obj.label, obj1]}>{obj1}</option>
                                    })
                                }</select>
                            </div>
                        })
                    }
                    <div className={styles.selectCompo}>
                        {
                            isId ? <>
                                <label>Set Id:</label>
                                <input className="text-right" name="KLS" type="text" placeholder="Enter KLS ID:" ref={(input) => this.menu3 = input} />
                                <button className={styles.change} type={"button"} onClick={changeId}>Change</button></>
                                : <div></div>
                        }
                    </div>
                </div>

                <div className={styles.viwContainer} >
                    <div className={styles.output} >
                        <JsonEditor jsonObject={jsonInput} readOnly={readonly} onChange={(output) => {
                            currentEditObj = output;
                        }} />
                    </div>


                    <div className={styles.middleContainer}>
                        {/* <div className={styles.toCopy}>
                            <button className={styles.toCopy} onClick={copyCodeToClipboard}>
                                <span>Copy to Clipboard</span>
                            </button>
                        </div> */}
                        {readonly ?
                            <div style={{ textAlign: "center" }}>
                                <button type={"button"} className={styles.toString} onClick={changeEdit}><span> EDIT</span>
                                </button>
                            </div>
                            :
                            <div style={{ textAlign: "center" }}>
                                <button type={"button"} className={styles.toString} onClick={saveJsonString}><span> Convert<i className={styles.arrowRight} /></span>
                                </button>
                            </div>}

                    </div>


                    <div className={styles.jsonContainer} >
                        <button className={styles.toCopy} onClick={copyCodeToClipboard}>
                                <span>Copy to Clipboard</span>
                        </button>
                        <textarea readOnly="true" value={jsonInput} ref={(textarea) => this.textArea = textarea} onChange={textSave} />
                    </div>

                </div>

            </div>

            <div className={styles.footer}>
                <span>&copy;Phantom Strikers</span>
            </div>

        </div >
    )
}
